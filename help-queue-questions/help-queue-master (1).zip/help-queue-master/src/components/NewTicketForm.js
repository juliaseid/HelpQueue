import React from "react";

function NewTicketForm(props){
  return (
    <React.Fragment>
      <h3>This is a form.</h3>
    </React.Fragment>
  );
}

export default NewTicketForm;