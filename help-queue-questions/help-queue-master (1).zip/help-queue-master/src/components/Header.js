import React from "react";

function Header(){
  return (
    <h1>Help Queue</h1>
  );
}

export default Header;